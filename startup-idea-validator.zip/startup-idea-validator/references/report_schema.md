# Report JSON Schema

Full field-by-field reference for the JSON object passed to
`scripts/generate_report.py`. Only `idea_name` and `overall_score` are required —
every other field, and every numeric sub-field inside `market`/`financials`, is
optional and gets skipped cleanly by the generator when absent. Never fabricate a
number to fill a field in — an omitted chart is always better than an invented one.

## Top-level fields

| Field | Type | Notes |
|---|---|---|
| `idea_name` | string | Required. Shown on the cover page. |
| `tagline` | string | One line under the title. |
| `date` | string | Defaults to today if omitted. |
| `overall_score` | number | Required. Sum of the seven category scores (0-100). |
| `categories` | array | See below. Drives both the radar chart and the bar list. |
| `executive_summary` | string | 2-4 honest sentences. |
| `strengths` | array of strings | |
| `weaknesses` | array of `{point, suggestion}` | |
| `opportunities` | array of strings | External/future factors that could help. |
| `threats` | array of strings | External/future factors that could hurt. |
| `ideal_customers` | array | See below. |
| `market` | object | See below. |
| `competitors` | array of `{name, description, differentiation}` | |
| `financials` | object | See below. |
| `legal_considerations` | array of strings | |
| `brand_names` | array of `{name, rationale}` | |
| `marketing_strategy` | object | `{positioning, phases: [{phase, actions}]}` |
| `verdict` | object | `{recommendation, next_steps}` |

## `categories`

```json
{"name": "Problem-Solution Fit", "score": 11, "max": 15, "comment": "..."}
```

Always include all seven from `scoring_rubric.md`, in order. The radar chart
normalizes each to percent-of-max, so a category scored out of 10 (Legal &
Regulatory Risk) sits on the same visual scale as one scored out of 15.

## SWOT: `strengths` / `weaknesses` / `opportunities` / `threats`

`strengths` and `opportunities` are plain string arrays. `weaknesses` items are
`{"point": "...", "suggestion": "..."}` so each weakness pairs with a fix.
`threats` are plain strings.

If `opportunities` or `threats` has at least one item, the PDF renders a full 2x2
SWOT quadrant. If both are empty, it falls back to the simpler
strengths/weaknesses-only layout (this is also what happens with older
`report_data.json` files that predate the SWOT expansion).

## `ideal_customers`

```json
{
  "persona": "Busy urban household (25-45)",
  "description": "...",
  "pain_points": "...",
  "why_they_buy": "..."
}
```

## `market`

```json
{
  "tam": "Qualitative TAM description",
  "sam": "Qualitative SAM description",
  "som": "Qualitative SOM description",
  "tam_value": 2100000000,
  "sam_value": 85000000,
  "som_value": 240000,
  "currency": "USD",
  "stats": ["Stat sentence with source noted in parentheses", "..."],
  "sources": ["Source name - URL", "..."]
}
```

The qualitative `tam`/`sam`/`som` strings are the primary content and should
always be filled in when you have research to support them. The `_value` fields
are optional numeric ballparks (same currency, in raw units — e.g. `2100000000`
for $2.1B, not `2.1`); when at least one is present, the report renders a
log-scale funnel bar chart alongside the text. Leave the numeric fields out
entirely rather than guessing a precise figure you can't defend.

## `financials`

Everything under `financials` is optional at every level — include only the
pieces you have real numbers for.

```json
{
  "currency": "USD",
  "startup_costs": [
    {"item": "Equipment", "cost": 900}
  ],
  "unit_economics": {
    "price_per_unit": 8.5,
    "cost_per_unit": 4.6,
    "cac": 6,
    "ltv": 34,
    "notes": "Optional short note on assumptions behind LTV/CAC."
  },
  "break_even": {
    "monthly_fixed_costs": 950,
    "contribution_margin_per_unit": 3.9,
    "breakeven_units_per_month": 244,
    "current_monthly_units": 140,
    "estimate_note": "Optional plain-language note on timing."
  }
}
```

Notes on computed values (the generator computes these — don't pre-compute them
yourself in the JSON):
- **Gross margin %** = `(price_per_unit - cost_per_unit) / price_per_unit`,
  labeled Healthy (>=50%) / Thin (25-49%) / Very thin (<25%).
- **LTV:CAC ratio** = `ltv / cac`, labeled Healthy (>=3x) / Marginal (1.5-3x) /
  Weak (<1.5x).
- **Break-even volume/month**, if not given directly, is computed as
  `monthly_fixed_costs / contribution_margin_per_unit` (falling back to
  `price_per_unit - cost_per_unit` for the margin if `contribution_margin_per_unit`
  isn't given separately).
- If `current_monthly_units` is present alongside a break-even volume, the report
  renders a comparison bar (current pace vs. break-even target).

`startup_costs` renders as an itemized table plus a pie chart. Skip it entirely if
you don't have real cost estimates — don't invent line items to populate the chart.

## Example

See `scripts/sample_input.json` for a complete, realistic example covering every
field, including the optional numeric market and financial fields.
