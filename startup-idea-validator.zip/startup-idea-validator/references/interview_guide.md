# Interview Question Bank

The goal of the interview is to fill gaps, not to run a fixed script. Before asking
anything, check what the person's initial pitch already covered — skip any topic
they've already answered, even partially. Most pitches leave 3-6 of these open; that's
the right number to ask about, not all of them.

## Topics to cover

- **Stage / maturity** — idea only, prototype/MVP, early customers, or already
  generating revenue.
- **Target customer** — B2C, B2B, B2B2C, or government/institutional; and roughly who
  within that (demographics, firmographics, or role).
- **Geography / market** — which city, country, or region they're starting in, and
  whether the plan is local-only or expected to expand.
- **Revenue model** — one-time sale, subscription, commission/marketplace fee, ads,
  freemium, or "not decided yet."
- **Competitive awareness** — what alternatives people currently use (including "doing
  nothing" or a manual workaround), and what the founder believes is different about
  their approach.
- **Pricing / economics** — a rough price point or budget, even a guess, if they have
  one. If they're comfortable sharing real numbers, also worth a light-touch ask
  about roughly what it costs to deliver one unit/order, any known startup costs
  (equipment, licensing, initial inventory), and estimated customer acquisition
  cost — these directly power the financial model section, but "don't know yet"
  is a completely fine answer and just means that part of the report is skipped
  rather than guessed at.
- **Team & resources** — solo or team, relevant technical/domain skills, and roughly
  how much capital or runway is available.
- **Legal/regulatory awareness** — anything they already know needs a license,
  certification, or registration.
- **Goals & timeline** — side project vs. full-time push, and whether they're
  planning to bootstrap or eventually raise money.

## How to ask

Split this into two passes so the person isn't stuck typing long answers to
everything:

**Pass 1 — quick-tap questions.** Use the `ask_user_input_v0` tool for anything that
maps cleanly onto a short list of options: stage/maturity, customer type, revenue
model are usually the best fits. Keep it to the 2-3 categorical gaps that matter most;
don't force something open-ended (like pricing or differentiation) into fake button
options just to use the tool.

**Pass 2 — open questions, bundled together.** For everything else (geography,
competitors, pricing specifics, team/resources, legal awareness, goals), ask them
together as a short numbered list in a single message rather than one question at a
time. This is a deliberate exception to the usual "one question per message" habit —
the person explicitly asked for a thorough interview, and rapid-fire single questions
would make this feel tedious rather than efficient. Keep the list itself short (aim
for 3-6 items) by only including genuine gaps.

If an answer reveals a new gap (e.g., they mention a competitor that raises a legal
question you hadn't considered), it's fine to follow up briefly rather than treating
the two passes as rigidly exhaustive.

## When to stop and move to research

Move on once you have at least a rough answer for: customer, geography, revenue model,
and competitive awareness. You don't need certainty on every topic — "not sure yet" is
a valid, usable answer, and it's fine to note that as a gap in the report itself
(e.g., under weaknesses: "pricing model not yet decided") rather than blocking on it.
