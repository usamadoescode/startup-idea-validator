# Scoring Rubric

Score every idea across these seven weighted categories. Points sum to 100, so the
`overall_score` in the report JSON is just the sum of the seven category scores.

For each category, write a one-to-two sentence `comment` that justifies the number —
tie it back to something specific the person said in the interview or something you
found in research. Avoid generic filler like "market looks decent." A good comment
sounds like it was written by someone who actually thought about *this* idea, not a
template. Ground scores in evidence rather than gut feel wherever research surfaced
something relevant, but interview answers count as real evidence too — don't wait for
a perfect stat before scoring.

## 1. Problem-Solution Fit (0-15)
How real, frequent, and painful is the problem, and how directly does the idea solve
it? A high score means the person can point to a specific recurring pain and the
product removes it, not just makes it slightly nicer. A low score means the "problem"
is closer to a mild inconvenience, or the solution only tangentially addresses it.

## 2. Market Size & Growth (0-15)
How many people/businesses have this problem, how much would they realistically pay,
and is the category growing or shrinking? Use research to ground this — a rough
TAM/SAM/SOM estimate, industry growth rate, or comparable company revenue all count.
Penalize ideas where the addressable market is real but tiny, or where growth is flat
or declining.

## 3. Competitive Differentiation (0-15)
Compare against both direct competitors and the "do nothing / current workaround"
alternative. A high score requires a differentiation that's hard to copy quickly
(network effects, proprietary data/recipe/technology, exclusive access, brand trust
built over time). A recipe, UI polish, or "we'll just execute better" is a real but
weak moat — score accordingly rather than either dismissing or overrating it.

## 4. Business Model / Monetization (0-15)
Is there a clear path to revenue, and do the unit economics plausibly work (price
point vs. cost to deliver, customer acquisition cost vs. lifetime value)? Score lower
if the revenue model is undecided, margins are structurally thin for the category, or
monetization depends on a step (e.g., "then we'll get ads") that isn't validated.

## 5. Execution Feasibility (0-15)
Given the founder's actual team, skills, capital, and time (as stated in the
interview), how realistic is it to actually build and run this? A solo non-technical
founder attempting a complex marketplace scores lower here than the same founder
attempting something that matches their existing skills and resources — this category
is about *this specific founder's* ability to execute, not the idea in the abstract.

## 6. Legal & Regulatory Risk (0-10)
How much regulatory friction stands between the idea and launch — licensing,
certification, data privacy, sector-specific compliance (food safety, financial
services, healthcare, etc.)? This category scores inversely to risk: heavy,
slow-moving compliance burden scores low; a straightforward business-registration-only
path scores high. Use research to identify what actually applies in the founder's
stated country/region and industry — don't default to generic boilerplate.

## 7. Go-to-Market / Timing (0-15)
Is now a good time for this, and is there a credible first channel to reach early
customers cheaply? Consider market timing (an emerging trend vs. a saturated,
commoditized category) and whether the founder has an identifiable first wedge
(an existing audience, a niche channel, a personal network) rather than needing to
win a cold, expensive channel from day one.

---

## Overall rating bands
The PDF generator computes these automatically from the summed score, but it's useful
to know them when writing the executive summary and verdict so your prose matches the
number:

| Score   | Label                              |
|---------|-------------------------------------|
| 85-100  | Excellent — strong potential         |
| 70-84   | Promising — some gaps to close       |
| 50-69   | Moderate — needs real refinement     |
| 30-49   | Weak — major rework required         |
| 0-29    | Not viable as-is                     |

Don't inflate scores to be encouraging, and don't be harsh for the sake of seeming
rigorous — the whole point of this tool is an honest, useful read. Most real early-stage
ideas land in the 40-75 range; reserve 85+ for ideas with genuinely rare combinations
of a sharp problem, a defensible edge, and a founder well-matched to execute it.
