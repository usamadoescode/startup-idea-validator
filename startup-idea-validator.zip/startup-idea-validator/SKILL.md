---
name: startup-idea-validator
description: Validates and scores a business or startup idea end-to-end — interviews the user, researches the market/competitors/legal landscape, scores it across weighted categories, and produces a polished PDF report with an overall score and radar chart, a full SWOT (strengths/weaknesses/opportunities/threats), ideal customer profiles, market size stats with an optional TAM/SAM/SOM funnel chart, a financial model (startup costs, unit economics with gross margin and LTV:CAC, break-even analysis), legal/regulatory considerations, brand name suggestions, and a phased marketing strategy. Use whenever the person pitches, describes, or brainstorms a business, startup, product, or side-hustle idea and wants feedback, validation, a score, a go/no-go opinion, or any structured report on it — even without the word "validate" or an explicit PDF request. Also use to re-score/refine an idea or compare two ideas using this same workflow.
---

# Startup Idea Validator

This skill turns a rough business pitch into a rigorous, evidence-grounded report:
an interview to fill gaps, real research to ground the analysis, honest scoring
against a fixed rubric, and a polished PDF the person can actually keep and share.

The whole point of this tool is candor. It's easy to default to encouraging,
generic feedback — resist that. The person is better served by an honest 55/100
with a clear list of what to fix than an inflated 80/100 that doesn't tell them
anything they didn't already believe.

## Workflow

### 1. Capture the idea

Let the person describe their idea in their own words first — don't interrupt with
questions before they've finished pitching. As they talk, mentally note what's
already been answered (customer, geography, revenue model, competitors, etc.) so
the next step only asks about genuine gaps.

### 2. Interview

Read `references/interview_guide.md` for the full topic list and the two-pass
approach (quick-tap questions via `ask_user_input_v0`, then a short bundled list of
open questions in one message). Only ask about what the pitch left open — if
someone already said "this is for small retailers in Lahore," don't ask about
geography again.

Don't over-interview. Once you have at least a rough read on customer, geography,
revenue model, and competitive awareness, move on — "not sure yet" is a fine answer
to leave as a noted gap in the report rather than something to keep pressing on.

### 3. Research

Read `references/scoring_rubric.md` before scoring — it defines exactly what each
category rewards and penalizes. Then use web search to ground the analysis instead
of relying on general impressions:

- Market size / industry growth for this specific niche and geography — look for
  an actual figure or range you can cite (even a rough one), not just a growth
  adjective, since a defensible number is what powers the market funnel chart
- Direct competitors and adjacent alternatives (including "what people do instead")
- Legal, licensing, or regulatory considerations specific to this industry and
  country/region (business registration type, sector-specific certification, tax
  basics, data privacy if relevant, etc.)
- Typical unit economics / cost structure for this category if the founder doesn't
  already know their numbers (e.g. typical margins for frozen food, typical CAC for
  a D2C app) — useful as a sanity check or fallback for the financial model, but
  say explicitly in the report when a number is an industry rule-of-thumb rather
  than the founder's own figure

Scale the number of searches to how niche/local the idea is — a handful of targeted
searches is usually enough (roughly 4-8), more if the market or regulatory picture
is unclear from the first pass. Follow standard search practice: paraphrase
everything, never quote sources directly, and keep a running list of source names
(not full citations) to include in the report's Sources line — the report is meant
to stand alone as the person's own document, not a research digest.

### 4. Score

Using `references/scoring_rubric.md`, assign a score to each of the seven
categories (they sum to 100) with a short, specific comment for each — tie every
comment back to something the person actually said or something research actually
turned up, not generic filler.

### 5. Build the report content

Assemble a single JSON object matching the schema documented at the top of
`scripts/generate_report.py` and in full in `references/report_schema.md`. Fill in
every section you have real content for:

- `executive_summary` — 2-4 honest sentences, not a hype paragraph
- `categories` — the seven scored categories from step 4 (this also drives an
  at-a-glance radar chart, so keep all seven even when a couple score low)
- `strengths` / `weaknesses` — weaknesses should each pair with a concrete
  suggestion, not just a criticism
- `opportunities` / `threats` — external factors that could help or hurt (market
  shifts, new channels, competitor moves, regulatory change). Include these
  whenever you have real ones to list — together with strengths/weaknesses they
  render as a full SWOT quadrant. It's fine to leave both out if the interview and
  research didn't surface anything beyond the internal strengths/weaknesses.
- `ideal_customers` — 1-3 personas, specific enough to be useful (not "everyone
  who likes convenience")
- `market` — TAM/SAM/SOM as honest ballpark ranges (not fabricated precision),
  plus the stats and sources from research. If you can ground a rough numeric
  estimate for each (`tam_value`/`sam_value`/`som_value`, plus `currency`), include
  them too — they render as a log-scale funnel chart. Never invent precise numbers
  just to populate the chart; leave them out if you don't have a defensible ballpark.
- `competitors` — direct and indirect, each with a concrete differentiation note
- `financials` — include only when the interview or research gave you real numbers
  to work with; never fabricate costs or prices to fill this section out:
  - `startup_costs` — itemized one-time costs (renders as a table + pie chart)
  - `unit_economics` — `price_per_unit`, `cost_per_unit`, `cac`, `ltv` as available;
    the generator computes gross margin and LTV:CAC ratio automatically
  - `break_even` — `monthly_fixed_costs` and/or `breakeven_units_per_month`; add
    `current_monthly_units` if the founder has real sales/pilot data so the report
    can chart current pace against the break-even target
- `legal_considerations` — specific to the stated industry and geography, not
  generic boilerplate
- `brand_names` — 3-5 suggestions with a one-line rationale each; mention that
  trademark/domain availability should still be checked before committing
- `marketing_strategy` — a positioning line plus phased actions (e.g., 0-3 / 3-6 /
  6-12 months)
- `verdict` — an overall recommendation and 2-4 concrete next steps

Skip a section (or a single field within `financials`/`market`) entirely if you
genuinely don't have enough real data to say — the generator handles missing
fields cleanly rather than needing placeholder text or invented numbers.

### 6. Generate the PDF

Write the JSON to a file (e.g. `/home/claude/report_data.json`), then run:

```bash
python3 <skill_path>/scripts/generate_report.py /home/claude/report_data.json /mnt/user-data/outputs/<idea-slug>-validation-report.pdf
```

Use a filesystem-friendly slug of the idea name for `<idea-slug>`. Then use
`present_files` to share the PDF.

### 7. Wrap up

After sharing the file, briefly (2-3 sentences, not a repeat of the whole report)
highlight the single biggest lever for improvement and ask if they want to go
deeper on any one section, adjust an assumption, or re-run the score after they've
answered an open question differently. Don't re-paste the full report content into
the chat — the PDF is the deliverable.

## Notes

- If someone wants to compare two ideas, run the full workflow for each and add a
  short comparison paragraph before generating two separate PDFs (or one PDF with
  two idea sections back to back — use judgment based on what they ask for).
- This is directional analysis to sharpen thinking, not a guarantee of success or a
  substitute for talking to real potential customers — it's fine to say so once,
  briefly, in the wrap-up if it feels relevant, without being preachy about it.
- The legal section is general awareness, not legal advice; the PDF itself already
  includes a line to that effect, so no need to over-caveat in chat.
