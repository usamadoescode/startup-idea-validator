#!/usr/bin/env python3
"""
Generate a Startup Idea Validation Report as a polished PDF.

Usage:
    python3 generate_report.py <input.json> <output.pdf>

Input JSON schema -- see references/report_schema.md for the full field-by-field
reference with examples. Quick overview of top-level fields:

{
  "idea_name": "KababKart",
  "tagline": "Frozen kababs, delivered fresh, made from a family recipe",
  "date": "July 21, 2026",
  "overall_score": 68,
  "categories": [
    {"name": "Problem-Solution Fit", "score": 11, "max": 15, "comment": "..."},
    ...
  ],
  "executive_summary": "2-4 sentence paragraph.",
  "strengths": ["...", "..."],
  "weaknesses": [{"point": "...", "suggestion": "..."}],
  "opportunities": ["...", "..."],
  "threats": ["...", "..."],
  "ideal_customers": [
    {"persona": "Name / label", "description": "...", "pain_points": "...", "why_they_buy": "..."}
  ],
  "market": {
    "tam": "...", "sam": "...", "som": "...",
    "tam_value": 1200000000, "sam_value": 45000000, "som_value": 500000,
    "currency": "USD",
    "stats": ["Stat sentence, with source in parentheses", "..."],
    "sources": ["Source name - URL", "..."]
  },
  "competitors": [
    {"name": "...", "description": "...", "differentiation": "..."}
  ],
  "financials": {
    "currency": "USD",
    "startup_costs": [{"item": "...", "cost": 1200}, ...],
    "unit_economics": {
      "price_per_unit": 8.5, "cost_per_unit": 4.2, "cac": 12, "ltv": 45,
      "notes": "..."
    },
    "break_even": {
      "monthly_fixed_costs": 1500,
      "contribution_margin_per_unit": 4.3,
      "current_monthly_units": 120,
      "estimate_note": "..."
    }
  },
  "legal_considerations": ["...", "..."],
  "brand_names": [{"name": "...", "rationale": "..."}],
  "marketing_strategy": {
    "positioning": "1-2 sentence positioning statement",
    "phases": [{"phase": "0-3 months", "actions": ["...", "..."]}, ...]
  },
  "verdict": {
    "recommendation": "Proceed / Proceed with caution / Reconsider / Not yet viable",
    "next_steps": ["...", "..."]
  }
}

All fields are optional except "idea_name" and "overall_score" -- missing sections,
and missing numeric inputs within the financials/market blocks, are simply skipped
in the output rather than fabricated, so partial reports still render cleanly.
"""

import sys
import json
import math
from datetime import datetime

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
    HRFlowable, ListFlowable, ListItem, KeepTogether,
)
from reportlab.graphics.shapes import Drawing, Rect, String
from reportlab.graphics.charts.spider import SpiderChart
from reportlab.graphics.charts.piecharts import Pie

# ---------------------------------------------------------------------------
# Palette / style constants
# ---------------------------------------------------------------------------
NAVY = colors.HexColor("#1B2A4A")
TEAL = colors.HexColor("#0E8378")
LIGHT_GREY = colors.HexColor("#F2F3F5")
MID_GREY = colors.HexColor("#6B7280")
GREEN = colors.HexColor("#2E9E5B")
AMBER = colors.HexColor("#D99A2B")
RED = colors.HexColor("#C4483A")
PURPLE = colors.HexColor("#7C6FBE")
WHITE = colors.white

STRENGTH_BG = colors.HexColor("#EAF7EF")
WEAKNESS_BG = colors.HexColor("#FBEAE8")
OPPORTUNITY_BG = colors.HexColor("#E6F5F4")
THREAT_BG = colors.HexColor("#FCF3E3")

PIE_PALETTE = [NAVY, TEAL, AMBER, PURPLE, MID_GREY, RED]

PAGE_W, PAGE_H = letter
MARGIN = 0.75 * inch


def score_color(fraction):
    """fraction is score/max, 0..1"""
    if fraction >= 0.7:
        return GREEN
    if fraction >= 0.45:
        return AMBER
    return RED


def rating_label(overall_score):
    if overall_score >= 85:
        return "Excellent \u2014 strong potential", GREEN
    if overall_score >= 70:
        return "Promising \u2014 some gaps to close", GREEN
    if overall_score >= 50:
        return "Moderate \u2014 needs real refinement", AMBER
    if overall_score >= 30:
        return "Weak \u2014 major rework required", RED
    return "Not viable as-is", RED


def fmt_money(value, currency="USD"):
    """Compact currency formatting: 1500 -> $1.5K, 2300000 -> $2.3M."""
    if value is None:
        return ""
    try:
        value = float(value)
    except (TypeError, ValueError):
        return str(value)
    symbol = "$" if str(currency).upper() == "USD" else f"{str(currency).upper()} "
    sign = "-" if value < 0 else ""
    v = abs(value)
    if v >= 1_000_000_000:
        return f"{sign}{symbol}{v/1_000_000_000:.2f}B"
    if v >= 1_000_000:
        return f"{sign}{symbol}{v/1_000_000:.2f}M"
    if v >= 1_000:
        return f"{sign}{symbol}{v/1_000:.1f}K"
    if v >= 100:
        return f"{sign}{symbol}{v:,.0f}"
    return f"{sign}{symbol}{v:,.2f}"


def gross_margin_label(pct):
    if pct >= 50:
        return "Healthy", GREEN
    if pct >= 25:
        return "Thin", AMBER
    return "Very thin", RED


def ltv_cac_label(ratio):
    if ratio >= 3:
        return "Healthy", GREEN
    if ratio >= 1.5:
        return "Marginal", AMBER
    return "Weak", RED


def build_styles():
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="ReportTitle", fontName="Helvetica-Bold", fontSize=26,
        leading=30, textColor=NAVY, alignment=TA_CENTER, spaceAfter=6,
    ))
    styles.add(ParagraphStyle(
        name="Tagline", fontName="Helvetica-Oblique", fontSize=13,
        leading=18, textColor=MID_GREY, alignment=TA_CENTER, spaceAfter=4,
    ))
    styles.add(ParagraphStyle(
        name="SectionHeading", fontName="Helvetica-Bold", fontSize=15,
        leading=18, textColor=NAVY, spaceBefore=18, spaceAfter=8,
    ))
    styles.add(ParagraphStyle(
        name="SubHeading", fontName="Helvetica-Bold", fontSize=11,
        leading=14, textColor=TEAL, spaceBefore=8, spaceAfter=4,
    ))
    styles.add(ParagraphStyle(
        name="Body", fontName="Helvetica", fontSize=10, leading=14,
        textColor=colors.HexColor("#26272B"), alignment=TA_LEFT,
    ))
    styles.add(ParagraphStyle(
        name="BodySmall", fontName="Helvetica", fontSize=9, leading=12,
        textColor=MID_GREY,
    ))
    styles.add(ParagraphStyle(
        name="BigScore", fontName="Helvetica-Bold", fontSize=54,
        leading=58, alignment=TA_CENTER,
    ))
    styles.add(ParagraphStyle(
        name="RatingLabel", fontName="Helvetica-Bold", fontSize=13,
        leading=16, alignment=TA_CENTER, spaceAfter=2,
    ))
    styles.add(ParagraphStyle(
        name="QuadrantBody", fontName="Helvetica", fontSize=9, leading=13,
        textColor=colors.HexColor("#26272B"),
    ))
    return styles


# ---------------------------------------------------------------------------
# Small chart / drawing helpers
# ---------------------------------------------------------------------------

def score_bar_drawing(score, max_score, width=320, height=14):
    fraction = max(0, min(1, score / max_score)) if max_score else 0
    d = Drawing(width, height)
    d.add(Rect(0, 0, width, height, fillColor=LIGHT_GREY, strokeColor=None))
    fill_w = width * fraction
    d.add(Rect(0, 0, fill_w, height, fillColor=score_color(fraction), strokeColor=None))
    return d


def plain_bar_drawing(fraction, color, width=260, height=14):
    fraction = max(0, min(1, fraction))
    d = Drawing(width, height)
    d.add(Rect(0, 0, width, height, fillColor=LIGHT_GREY, strokeColor=None))
    d.add(Rect(0, 0, width * fraction, height, fillColor=color, strokeColor=None))
    return d


def color_swatch(color, size=9):
    d = Drawing(size, size)
    d.add(Rect(0, 0, size, size, fillColor=color, strokeColor=None))
    return d


def score_radar_drawing(categories, size=260):
    """categories: list of {name, score, max}. Renders a spider/radar chart
    normalized to percent-of-max per category, with a dashed 100% reference ring."""
    if not categories:
        return None
    labels = []
    pcts = []
    for c in categories:
        max_v = c.get("max") or 1
        pct = max(0, min(100, (c.get("score", 0) / max_v) * 100)) if max_v else 0
        # shorten long labels so they don't overlap on the chart
        name = c.get("name", "")
        labels.append(name)
        pcts.append(pct)

    d = Drawing(size + 60, size + 20)
    sc = SpiderChart()
    sc.x = 30
    sc.y = 15
    sc.width = size
    sc.height = size
    sc.data = [[100] * len(pcts), pcts]
    sc.labels = labels
    sc.strands[0].strokeColor = colors.HexColor("#D9DBDF")
    sc.strands[0].strokeDashArray = [2, 2]
    sc.strands[0].strokeWidth = 0.75
    sc.strands[0].fillColor = None
    sc.strands[1].strokeColor = TEAL
    sc.strands[1].fillColor = colors.Color(0.055, 0.514, 0.471, alpha=0.30)
    sc.strands[1].strokeWidth = 1.5
    sc.spokes.strokeColor = colors.HexColor("#EDEEF0")
    sc.spokeLabels.fontName = "Helvetica"
    sc.spokeLabels.fontSize = 7
    sc.spokeLabels.fillColor = MID_GREY
    d.add(sc)
    return d


def log_fraction(value, max_value, floor=0.06):
    """Fraction (0-1) on a log10 scale, with a floor so small-but-real values
    (e.g. SOM next to TAM) still show a visible sliver of bar."""
    if not value or not max_value or value <= 0 or max_value <= 0:
        return 0
    f = math.log10(value + 1) / math.log10(max_value + 1)
    return max(f, floor)


def pie_drawing(values, size=150):
    d = Drawing(size, size)
    pie = Pie()
    pie.x = 5
    pie.y = 5
    pie.width = size - 10
    pie.height = size - 10
    pie.data = values
    pie.labels = None
    pie.slices.strokeWidth = 0.75
    pie.slices.strokeColor = colors.white
    for i in range(len(values)):
        pie.slices[i].fillColor = PIE_PALETTE[i % len(PIE_PALETTE)]
    d.add(pie)
    return d


# ---------------------------------------------------------------------------
# Report sections
# ---------------------------------------------------------------------------

def cover_page(data, styles, story):
    story.append(Spacer(1, 0.6 * inch))
    story.append(Paragraph("STARTUP IDEA VALIDATION REPORT", ParagraphStyle(
        name="Kicker", fontName="Helvetica-Bold", fontSize=10, leading=12,
        textColor=TEAL, alignment=TA_CENTER, spaceAfter=14,
    )))
    story.append(Paragraph(data.get("idea_name", "Untitled Idea"), styles["ReportTitle"]))
    if data.get("tagline"):
        story.append(Paragraph(data["tagline"], styles["Tagline"]))
    story.append(Spacer(1, 0.5 * inch))

    overall = data.get("overall_score")
    if overall is not None:
        label, color = rating_label(overall)
        story.append(Paragraph(f'<font color="{color.hexval()}">{overall}</font><font color="#6B7280" size="20">/100</font>', styles["BigScore"]))
        story.append(Paragraph(label, ParagraphStyle(
            name="RatingColored", parent=styles["RatingLabel"], textColor=color,
        )))
    story.append(Spacer(1, 0.6 * inch))
    story.append(HRFlowable(width="60%", thickness=1, color=LIGHT_GREY, hAlign="CENTER"))
    story.append(Spacer(1, 0.2 * inch))
    date_str = data.get("date") or datetime.now().strftime("%B %d, %Y")
    story.append(Paragraph(date_str, ParagraphStyle(
        name="DateLine", fontName="Helvetica", fontSize=10, textColor=MID_GREY,
        alignment=TA_CENTER,
    )))
    story.append(PageBreak())


def section_heading(text, styles, story):
    story.append(Paragraph(text, styles["SectionHeading"]))
    story.append(HRFlowable(width="100%", thickness=0.75, color=LIGHT_GREY))
    story.append(Spacer(1, 6))


def bullet_list(items, styles, story, bullet="\u2022"):
    flow_items = [ListItem(Paragraph(str(it), styles["Body"]), leftIndent=12) for it in items]
    story.append(ListFlowable(flow_items, bulletType="bullet", start=bullet, leftIndent=8))


def executive_summary_section(data, styles, story):
    if not data.get("executive_summary"):
        return
    section_heading("Executive Summary", styles, story)
    story.append(Paragraph(data["executive_summary"], styles["Body"]))


def score_breakdown_section(data, styles, story):
    categories = data.get("categories") or []
    if not categories:
        return
    section_heading("Score Breakdown", styles, story)

    radar = score_radar_drawing(categories) if len(categories) >= 3 else None
    if radar:
        story.append(radar)
        story.append(Spacer(1, 4))

    for cat in categories:
        name = cat.get("name", "Category")
        score = cat.get("score", 0)
        max_score = cat.get("max", 10)
        row = Table(
            [[Paragraph(f"<b>{name}</b>", styles["Body"]),
              Paragraph(f"{score}/{max_score}", ParagraphStyle(
                  name="ScoreNum", parent=styles["Body"], alignment=TA_CENTER,
              )),
              score_bar_drawing(score, max_score)]],
            colWidths=[2.3 * inch, 0.7 * inch, 3.3 * inch],
        )
        row.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 0),
            ("RIGHTPADDING", (0, 0), (-1, -1), 0),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        story.append(row)
        if cat.get("comment"):
            story.append(Paragraph(cat["comment"], styles["BodySmall"]))
        story.append(Spacer(1, 6))


def _stringify_weakness(w):
    if isinstance(w, dict):
        text = f"<b>{w.get('point', '')}</b>"
        if w.get("suggestion"):
            text += f" \u2014 {w['suggestion']}"
        return text
    return str(w)


def _quadrant_paragraph(title, items, color, styles):
    if items:
        body = "<br/>".join(f"\u2022 {it}" for it in items)
    else:
        body = '<font color="#6B7280"><i>None identified</i></font>'
    header = f'<font color="{color.hexval()}"><b>{title}</b></font>'
    return Paragraph(header + "<br/>" + body, styles["QuadrantBody"])


def swot_section(data, styles, story):
    strengths = data.get("strengths") or []
    weaknesses = [_stringify_weakness(w) for w in (data.get("weaknesses") or [])]
    opportunities = data.get("opportunities") or []
    threats = data.get("threats") or []

    if not any([strengths, weaknesses, opportunities, threats]):
        return

    section_heading("SWOT Analysis", styles, story)

    if opportunities or threats:
        # Full 2x2 quadrant grid
        cell_style = TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 10),
            ("RIGHTPADDING", (0, 0), (-1, -1), 10),
            ("TOPPADDING", (0, 0), (-1, -1), 10),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 10),
            ("BACKGROUND", (0, 0), (0, 0), STRENGTH_BG),
            ("BACKGROUND", (1, 0), (1, 0), WEAKNESS_BG),
            ("BACKGROUND", (0, 1), (0, 1), OPPORTUNITY_BG),
            ("BACKGROUND", (1, 1), (1, 1), THREAT_BG),
            ("GRID", (0, 0), (-1, -1), 4, WHITE),
        ])
        grid = Table(
            [
                [_quadrant_paragraph("Strengths", strengths, GREEN, styles),
                 _quadrant_paragraph("Weaknesses", weaknesses, RED, styles)],
                [_quadrant_paragraph("Opportunities", opportunities, TEAL, styles),
                 _quadrant_paragraph("Threats", threats, AMBER, styles)],
            ],
            colWidths=[3.1 * inch, 3.1 * inch],
        )
        grid.setStyle(cell_style)
        story.append(grid)
    else:
        # Backward-compatible simple layout when only S/W were provided
        if strengths:
            story.append(Paragraph("Strengths", styles["SubHeading"]))
            bullet_list(strengths, styles, story)
        if weaknesses:
            story.append(Spacer(1, 6))
            story.append(Paragraph("Weaknesses & How to Address Them", styles["SubHeading"]))
            bullet_list(weaknesses, styles, story)


def ideal_customers_section(data, styles, story):
    personas = data.get("ideal_customers") or []
    if not personas:
        return
    section_heading("Ideal Customer Profiles", styles, story)
    for p in personas:
        story.append(Paragraph(p.get("persona", "Customer Segment"), styles["SubHeading"]))
        rows = []
        if p.get("description"):
            rows.append(["Who they are", p["description"]])
        if p.get("pain_points"):
            rows.append(["Pain points", p["pain_points"]])
        if p.get("why_they_buy"):
            rows.append(["Why they'd buy", p["why_they_buy"]])
        if rows:
            table_data = [[Paragraph(f"<b>{r[0]}</b>", styles["Body"]), Paragraph(r[1], styles["Body"])] for r in rows]
            t = Table(table_data, colWidths=[1.3 * inch, 4.7 * inch])
            t.setStyle(TableStyle([
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("BACKGROUND", (0, 0), (0, -1), LIGHT_GREY),
                ("GRID", (0, 0), (-1, -1), 0.5, LIGHT_GREY),
                ("LEFTPADDING", (0, 0), (-1, -1), 6),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]))
            story.append(t)
        story.append(Spacer(1, 10))


def market_section(data, styles, story):
    market = data.get("market") or {}
    if not market:
        return
    section_heading("Market Size & Signals", styles, story)
    tam_sam_som = [(k.upper(), market[k]) for k in ("tam", "sam", "som") if market.get(k)]
    if tam_sam_som:
        table_data = [[Paragraph(f"<b>{k}</b>", styles["Body"]), Paragraph(v, styles["Body"])] for k, v in tam_sam_som]
        t = Table(table_data, colWidths=[0.8 * inch, 5.2 * inch])
        t.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("BACKGROUND", (0, 0), (0, -1), LIGHT_GREY),
            ("GRID", (0, 0), (-1, -1), 0.5, LIGHT_GREY),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ]))
        story.append(t)
        story.append(Spacer(1, 8))

    # Optional numeric funnel chart when tam_value/sam_value/som_value are given
    currency = market.get("currency", "USD")
    numeric = [(k.upper(), market.get(f"{k}_value")) for k in ("tam", "sam", "som")]
    numeric = [(k, v) for k, v in numeric if v]
    if numeric:
        max_val = max(v for _, v in numeric)
        bar_colors = {"TAM": NAVY, "SAM": TEAL, "SOM": AMBER}
        story.append(Paragraph("Market Funnel (log scale)", styles["SubHeading"]))
        for k, v in numeric:
            frac = log_fraction(v, max_val)
            row = Table(
                [[Paragraph(f"<b>{k}</b>", styles["Body"]),
                  Paragraph(fmt_money(v, currency), ParagraphStyle(
                      name="MoneyNum", parent=styles["Body"], alignment=TA_LEFT,
                  )),
                  plain_bar_drawing(frac, bar_colors.get(k, TEAL))]],
                colWidths=[0.6 * inch, 0.9 * inch, 4.4 * inch],
            )
            row.setStyle(TableStyle([
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("LEFTPADDING", (0, 0), (-1, -1), 0),
                ("TOPPADDING", (0, 0), (-1, -1), 3),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
            ]))
            story.append(row)
        story.append(Spacer(1, 8))

    if market.get("stats"):
        story.append(Paragraph("Key Stats", styles["SubHeading"]))
        bullet_list(market["stats"], styles, story)
    if market.get("sources"):
        story.append(Spacer(1, 6))
        story.append(Paragraph("Sources: " + "; ".join(market["sources"]), styles["BodySmall"]))


def competitors_section(data, styles, story):
    competitors = data.get("competitors") or []
    if not competitors:
        return
    section_heading("Competitive Landscape", styles, story)
    table_data = [["Competitor / Alternative", "What they do", "Your differentiation"]]
    for c in competitors:
        table_data.append([
            Paragraph(f"<b>{c.get('name', '')}</b>", styles["BodySmall"]),
            Paragraph(c.get("description", ""), styles["BodySmall"]),
            Paragraph(c.get("differentiation", ""), styles["BodySmall"]),
        ])
    t = Table(table_data, colWidths=[1.4 * inch, 2.4 * inch, 2.4 * inch])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 9),
        ("GRID", (0, 0), (-1, -1), 0.5, LIGHT_GREY),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, LIGHT_GREY]),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    story.append(t)


def _financial_stat_table(rows, styles):
    table_data = [[Paragraph(f"<b>{r[0]}</b>", styles["Body"]), Paragraph(r[1], styles["Body"])] for r in rows]
    t = Table(table_data, colWidths=[2.4 * inch, 3.6 * inch])
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BACKGROUND", (0, 0), (0, -1), LIGHT_GREY),
        ("GRID", (0, 0), (-1, -1), 0.5, LIGHT_GREY),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]))
    return t


def financials_section(data, styles, story):
    fin = data.get("financials") or {}
    if not fin:
        return
    currency = fin.get("currency", "USD")
    section_heading("Financial Model", styles, story)

    # --- Startup costs -----------------------------------------------------
    startup_costs = [c for c in (fin.get("startup_costs") or []) if c.get("cost")]
    if startup_costs:
        story.append(Paragraph("Startup Costs", styles["SubHeading"]))
        total = sum(c["cost"] for c in startup_costs)
        rows = [["", "Item", "Cost", "% of total"]]
        for i, c in enumerate(startup_costs):
            color = PIE_PALETTE[i % len(PIE_PALETTE)]
            pct = (c["cost"] / total * 100) if total else 0
            rows.append([
                color_swatch(color),
                Paragraph(c.get("item", ""), styles["BodySmall"]),
                Paragraph(fmt_money(c["cost"], currency), styles["BodySmall"]),
                Paragraph(f"{pct:.0f}%", styles["BodySmall"]),
            ])
        rows.append([
            "", Paragraph("<b>Total</b>", styles["BodySmall"]),
            Paragraph(f"<b>{fmt_money(total, currency)}</b>", styles["BodySmall"]), "",
        ])
        cost_table = Table(rows, colWidths=[0.25 * inch, 2.05 * inch, 0.9 * inch, 0.7 * inch])
        cost_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), NAVY),
            ("TEXTCOLOR", (1, 0), (-1, 0), WHITE),
            ("FONTNAME", (1, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, 0), 8),
            ("GRID", (0, 0), (-1, -1), 0.5, LIGHT_GREY),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LINEABOVE", (0, -1), (-1, -1), 0.75, MID_GREY),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        pie = pie_drawing([c["cost"] for c in startup_costs])
        layout = Table([[cost_table, pie]], colWidths=[3.9 * inch, 2.3 * inch])
        layout.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("LEFTPADDING", (0, 0), (-1, -1), 0),
            ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ]))
        story.append(layout)
        story.append(Spacer(1, 10))

    # --- Unit economics ------------------------------------------------------
    unit = fin.get("unit_economics") or {}
    price = unit.get("price_per_unit")
    cost = unit.get("cost_per_unit")
    cac = unit.get("cac")
    ltv = unit.get("ltv")
    if any(v is not None for v in (price, cost, cac, ltv)):
        story.append(Paragraph("Unit Economics", styles["SubHeading"]))
        rows = []
        if price is not None:
            rows.append(["Price per unit", fmt_money(price, currency)])
        if cost is not None:
            rows.append(["Cost per unit (COGS)", fmt_money(cost, currency)])
        if price is not None and cost is not None and price:
            margin_pct = (price - cost) / price * 100
            label, color = gross_margin_label(margin_pct)
            rows.append(["Gross margin", f'{margin_pct:.0f}% \u2014 <font color="{color.hexval()}"><b>{label}</b></font>'])
        if cac is not None:
            rows.append(["Customer acquisition cost (CAC)", fmt_money(cac, currency)])
        if ltv is not None:
            rows.append(["Lifetime value (LTV)", fmt_money(ltv, currency)])
        if cac and ltv is not None and cac:
            ratio = ltv / cac
            label, color = ltv_cac_label(ratio)
            rows.append(["LTV : CAC ratio", f'{ratio:.1f}x \u2014 <font color="{color.hexval()}"><b>{label}</b></font>'])
        if rows:
            story.append(_financial_stat_table(rows, styles))
        if unit.get("notes"):
            story.append(Spacer(1, 4))
            story.append(Paragraph(unit["notes"], styles["BodySmall"]))
        story.append(Spacer(1, 10))

    # --- Break-even ------------------------------------------------------
    be = fin.get("break_even") or {}
    fixed = be.get("monthly_fixed_costs")
    contrib = be.get("contribution_margin_per_unit")
    if contrib is None and price is not None and cost is not None:
        contrib = price - cost
    breakeven_units = be.get("breakeven_units_per_month")
    if breakeven_units is None and fixed and contrib and contrib > 0:
        breakeven_units = fixed / contrib
    breakeven_revenue = (breakeven_units * price) if breakeven_units and price else None

    if fixed is not None or breakeven_units is not None:
        story.append(Paragraph("Break-Even Analysis", styles["SubHeading"]))
        rows = []
        if fixed is not None:
            rows.append(["Monthly fixed costs", fmt_money(fixed, currency)])
        if contrib is not None:
            rows.append(["Contribution margin / unit", fmt_money(contrib, currency)])
        if breakeven_units is not None:
            rows.append(["Break-even volume / month", f"{breakeven_units:,.0f} units"])
        elif fixed and (contrib is not None) and contrib <= 0:
            rows.append(["Break-even volume / month", "Not reachable \u2014 contribution margin is zero or negative"])
        if breakeven_revenue is not None:
            rows.append(["Break-even revenue / month", fmt_money(breakeven_revenue, currency)])
        if rows:
            story.append(_financial_stat_table(rows, styles))

        current_units = be.get("current_monthly_units")
        if current_units is not None and breakeven_units:
            story.append(Spacer(1, 8))
            max_units = max(current_units, breakeven_units)
            for label, val, color in [
                ("Current pace", current_units, AMBER if current_units < breakeven_units else GREEN),
                ("Break-even target", breakeven_units, MID_GREY),
            ]:
                frac = max(0, min(1, val / max_units)) if max_units else 0
                row = Table(
                    [[Paragraph(f"<b>{label}</b>", styles["BodySmall"]),
                      Paragraph(f"{val:,.0f}/mo", styles["BodySmall"]),
                      plain_bar_drawing(frac, color)]],
                    colWidths=[1.3 * inch, 0.9 * inch, 3.7 * inch],
                )
                row.setStyle(TableStyle([
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 0),
                    ("TOPPADDING", (0, 0), (-1, -1), 3),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ]))
                story.append(row)
        if be.get("estimate_note"):
            story.append(Spacer(1, 4))
            story.append(Paragraph(be["estimate_note"], styles["BodySmall"]))


def legal_section(data, styles, story):
    legal = data.get("legal_considerations") or []
    if not legal:
        return
    section_heading("Legal & Regulatory Considerations", styles, story)
    bullet_list(legal, styles, story)
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        "This is general awareness, not legal advice \u2014 confirm specifics with a local lawyer or accountant before launching.",
        styles["BodySmall"],
    ))


def brand_names_section(data, styles, story):
    names = data.get("brand_names") or []
    if not names:
        return
    section_heading("Brand Name Suggestions", styles, story)
    items = []
    for n in names:
        if isinstance(n, dict):
            items.append(f"<b>{n.get('name', '')}</b> \u2014 {n.get('rationale', '')}")
        else:
            items.append(str(n))
    bullet_list(items, styles, story)


def marketing_section(data, styles, story):
    marketing = data.get("marketing_strategy") or {}
    if not marketing:
        return
    section_heading("Marketing Strategy", styles, story)
    if marketing.get("positioning"):
        story.append(Paragraph(f"<b>Positioning:</b> {marketing['positioning']}", styles["Body"]))
        story.append(Spacer(1, 8))
    for phase in marketing.get("phases", []):
        story.append(Paragraph(phase.get("phase", "Phase"), styles["SubHeading"]))
        bullet_list(phase.get("actions", []), styles, story)
        story.append(Spacer(1, 6))


def verdict_section(data, styles, story):
    verdict = data.get("verdict") or {}
    if not verdict:
        return
    section_heading("Final Verdict & Next Steps", styles, story)
    if verdict.get("recommendation"):
        story.append(Paragraph(f"<b>Recommendation:</b> {verdict['recommendation']}", styles["Body"]))
        story.append(Spacer(1, 6))
    if verdict.get("next_steps"):
        story.append(Paragraph("Next Steps", styles["SubHeading"]))
        bullet_list(verdict["next_steps"], styles, story)


def build_pdf(data, output_path):
    doc = SimpleDocTemplate(
        output_path, pagesize=letter,
        leftMargin=MARGIN, rightMargin=MARGIN, topMargin=0.6 * inch, bottomMargin=0.6 * inch,
        title=data.get("idea_name", "Startup Idea Validation Report"),
    )
    styles = build_styles()
    story = []

    cover_page(data, styles, story)
    executive_summary_section(data, styles, story)
    score_breakdown_section(data, styles, story)
    swot_section(data, styles, story)
    ideal_customers_section(data, styles, story)
    market_section(data, styles, story)
    competitors_section(data, styles, story)
    financials_section(data, styles, story)
    legal_section(data, styles, story)
    brand_names_section(data, styles, story)
    marketing_section(data, styles, story)
    verdict_section(data, styles, story)

    doc.build(story)


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 generate_report.py <input.json> <output.pdf>")
        sys.exit(1)
    input_path, output_path = sys.argv[1], sys.argv[2]
    with open(input_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    build_pdf(data, output_path)
    print(f"Report written to {output_path}")


if __name__ == "__main__":
    main()
